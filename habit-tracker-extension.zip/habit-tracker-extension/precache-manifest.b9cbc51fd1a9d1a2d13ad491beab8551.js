self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "083ee64c96416bc1e1b2efb3e77084aa",
    "url": "/index.html"
  },
  {
    "revision": "22e8ec951d70e8dc4293",
    "url": "/static/css/main.4541a196.chunk.css"
  },
  {
    "revision": "7157dbc16004f2e9041b",
    "url": "/static/js/2.f0de4ccc.chunk.js"
  },
  {
    "revision": "5843ec24999d9bc4d5892cbe88e32df5",
    "url": "/static/js/2.f0de4ccc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "22e8ec951d70e8dc4293",
    "url": "/static/js/main.d11636e3.chunk.js"
  },
  {
    "revision": "4ba25ac5d173844fff46",
    "url": "/static/js/runtime-main.64e1d09e.js"
  },
  {
    "revision": "d847de26cfdbc572c4d53b46a0f5f001",
    "url": "/static/media/archiveIcon.d847de26.svg"
  },
  {
    "revision": "41f19ae157363f919b9e1e7bf992e1b3",
    "url": "/static/media/arrowDecrease.41f19ae1.svg"
  },
  {
    "revision": "21e3eb24e8ce8e74aaa3ff366fba2745",
    "url": "/static/media/arrowIncrease.21e3eb24.svg"
  },
  {
    "revision": "74b4ad6c84b98eda9eaf078171b524cd",
    "url": "/static/media/backgroundConfetti.74b4ad6c.svg"
  },
  {
    "revision": "0d721c0ba88b5a9a46e30bae8be31ba5",
    "url": "/static/media/chartIcon.0d721c0b.svg"
  },
  {
    "revision": "49176a7c798a1cb75d5efbcaeda9a05e",
    "url": "/static/media/check.49176a7c.svg"
  },
  {
    "revision": "009848185999daa029dd3abd54e70b54",
    "url": "/static/media/downDark.00984818.svg"
  },
  {
    "revision": "c2df1251241a898d9e14bd182b4f8a3c",
    "url": "/static/media/exit.c2df1251.svg"
  },
  {
    "revision": "f4f2ec591b59bd34d5ab3d0c0f27806c",
    "url": "/static/media/exitSmall.f4f2ec59.svg"
  },
  {
    "revision": "b4b6a792cbf9f5e28d79b9be43b3e358",
    "url": "/static/media/facebookIcon.b4b6a792.svg"
  },
  {
    "revision": "0b34264b245d6fe4ee1fee25a8389bdd",
    "url": "/static/media/firstHabitIcon.0b34264b.svg"
  },
  {
    "revision": "48d4a808cb3cdd5c0e356e2268e9b062",
    "url": "/static/media/googleIcon.48d4a808.svg"
  },
  {
    "revision": "f571bb9018d4f517e19105d5371e77c6",
    "url": "/static/media/help-circle.f571bb90.svg"
  },
  {
    "revision": "2fccbef7308edf5cb6a00a39190ffa17",
    "url": "/static/media/inputError.2fccbef7.svg"
  },
  {
    "revision": "5543a6dfe2d73f0c63c9392e2087169d",
    "url": "/static/media/left-arrow-inactive.5543a6df.svg"
  },
  {
    "revision": "8f035a99846f6d78eb8526463484546a",
    "url": "/static/media/left-arrow.8f035a99.svg"
  },
  {
    "revision": "a1690fa4ba82099099719b1cf860aaaf",
    "url": "/static/media/loading.a1690fa4.gif"
  },
  {
    "revision": "3f78fbe631f126ad5259aacb048ad833",
    "url": "/static/media/logo-white.3f78fbe6.svg"
  },
  {
    "revision": "e343099a7fb72e88823ea9256fa32f29",
    "url": "/static/media/logo.e343099a.svg"
  },
  {
    "revision": "b8df4ea7995c8e0b38026dab2e5a5ebb",
    "url": "/static/media/not-to-do.b8df4ea7.svg"
  },
  {
    "revision": "5b8bc2bc89ba02fe872a0bb1673055b6",
    "url": "/static/media/numberInput.5b8bc2bc.svg"
  },
  {
    "revision": "099d5fc431f98e259fb4fc07ad243abd",
    "url": "/static/media/onboardingWelcome.099d5fc4.png"
  },
  {
    "revision": "804a1da48f0ac65335c76d2ab11027a8",
    "url": "/static/media/plus.804a1da4.svg"
  },
  {
    "revision": "731865813b7b5699c997b5b4483c4925",
    "url": "/static/media/progressIcon.73186581.svg"
  },
  {
    "revision": "536a5ab06fbce0f8863d7a69063cae1b",
    "url": "/static/media/relax.536a5ab0.png"
  },
  {
    "revision": "12057bbb0a2c1db69a93b6e0dba9d200",
    "url": "/static/media/repeat.12057bbb.svg"
  },
  {
    "revision": "cd4f6135adb01d50645adcfc7673711b",
    "url": "/static/media/right-arrow-inactive.cd4f6135.svg"
  },
  {
    "revision": "d19c7c0fd3f3dd53cccabd9c38cc07c0",
    "url": "/static/media/right-arrow.d19c7c0f.svg"
  },
  {
    "revision": "1cb1464709dfe129bc98b985c4531e46",
    "url": "/static/media/setBedtimeIcon.1cb14647.svg"
  },
  {
    "revision": "61bbf1e448967bbb5ddff75bab6c1c5f",
    "url": "/static/media/settings.61bbf1e4.svg"
  },
  {
    "revision": "d0591b6dfe3e7a2466c62b966db80a38",
    "url": "/static/media/streakIcon.d0591b6d.svg"
  },
  {
    "revision": "163560599f2ba605ecd3553cc9e982c4",
    "url": "/static/media/streakIconRed.16356059.svg"
  },
  {
    "revision": "b80ecd40c7a63d557fbb6a0a51f855af",
    "url": "/static/media/trashIcon.b80ecd40.svg"
  },
  {
    "revision": "3882eccc584ecd3b7ba34c6ff5e5da78",
    "url": "/static/media/verticalDots-grey.3882eccc.svg"
  },
  {
    "revision": "97b378f5a8ef6ddcd7405636fa55aa9e",
    "url": "/static/media/verticalDots-white.97b378f5.svg"
  }
]);